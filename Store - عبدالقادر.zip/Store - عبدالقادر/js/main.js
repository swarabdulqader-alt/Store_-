(() => {
  // Header year
  document.getElementById('year') && (document.getElementById('year').textContent = new Date().getFullYear());

  // Mobile nav toggle
  const toggleBtn = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.nav');
  if (toggleBtn && nav) {
    toggleBtn.addEventListener('click', () => {
      const open = nav.style.display === 'block';
      nav.style.display = open ? 'none' : 'block';
    });
  }

  // Toast helper
  const toastEl = document.getElementById('toast');
  function showToast(msg, type='success') {
    if (!toastEl) return;
    toastEl.textContent = msg;
    toastEl.className = `toast show ${type}`;
    setTimeout(() => toastEl.className = 'toast', 2400);
  }
  window.__showToast = showToast;

  // Slider
  const slidesWrap = document.querySelector('.slides');
  const slideEls = document.querySelectorAll('.slide');
  const nextBtn = document.querySelector('.next');
  const prevBtn = document.querySelector('.prev');
  const dots = document.querySelector('.dots');
  let index = 0;
  function go(i){
    if(!slidesWrap) return;
    index = (i + slideEls.length) % slideEls.length;
    slidesWrap.style.transform = `translateX(-${index*100}%)`;
    if (dots) {
      [...dots.children].forEach((d, k)=> d.classList.toggle('active', k===index));
    }
  }
  if (dots && slideEls.length) {
    slideEls.forEach((_, i) => {
      const b = document.createElement('button');
      if (i===0) b.classList.add('active');
      b.addEventListener('click', ()=>go(i));
      dots.appendChild(b);
    });
  }
  nextBtn && nextBtn.addEventListener('click', ()=>go(index+1));
  prevBtn && prevBtn.addEventListener('click', ()=>go(index-1));
  if (slideEls.length) {
    setInterval(()=>go(index+1), 5000);
  }

  // Add to cart demo
  document.querySelectorAll('.add-to-cart').forEach(btn => {
    btn.addEventListener('click', () => {
      const name = btn.dataset.name;
      const price = btn.dataset.price;
      showToast(`تمت إضافة "${name}" (${price} ر.س) إلى السلة.`);
    });
  });

  // Simple validators
  const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  function bindForm(formId, onSubmit){
    const form = document.getElementById(formId);
    if(!form) return;
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      let ok = true;
      form.querySelectorAll('.error').forEach(el => el.textContent = '');

      form.querySelectorAll('input[required], textarea[required]').forEach(inp => {
        if (!inp.value.trim()) {
          ok = false;
          inp.parentElement.querySelector('.error').textContent = 'هذا الحقل مطلوب';
        }
      });

      const email = form.querySelector('input[type="email"]');
      if (email && email.value && !emailRe.test(email.value)) {
        ok = false;
        email.parentElement.querySelector('.error').textContent = 'صيغة البريد غير صحيحة';
      }

      const pass = form.querySelector('input[name="password"]');
      if (pass && pass.value && pass.getAttribute('minlength')) {
        if (pass.value.length < parseInt(pass.getAttribute('minlength'))) {
          ok = false;
          pass.parentElement.querySelector('.error').textContent = 'كلمة المرور قصيرة';
        }
      }

      const confirm = form.querySelector('input[name="confirm"]');
      if (confirm && pass && confirm.value !== pass.value) {
        ok = false;
        confirm.parentElement.querySelector('.error').textContent = 'كلمتا المرور غير متطابقتين';
      }

      if (ok) {
        onSubmit && onSubmit(new FormData(form));
      }
    });
  }

  bindForm('contactForm', (fd) => {
    showToast('تم استلام رسالتك بنجاح ✅');
  });
  bindForm('loginForm', (fd) => {
    showToast('تم تسجيل الدخول ✅');
  });
  bindForm('registerForm', (fd) => {
    showToast('تم إنشاء الحساب ✅');
  });
})();
